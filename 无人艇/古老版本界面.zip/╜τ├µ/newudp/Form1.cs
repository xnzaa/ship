﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace newudp
{
    public partial class Form1 : Form
    {
        public Thread udp,udps;
        public static string[] str1;
        public static  string  ch; 
        UdpClient udpclient = new UdpClient(int.Parse("9998")) ;
        public Form1()
        {
            InitializeComponent();
            button3s.Click +=new EventHandler(button3s_Click);
            button4z .Click +=new EventHandler(button3s_Click);
            button5y .Click +=new EventHandler(button3s_Click);
            button6x .Click +=new EventHandler(button3s_Click);
           
        }
        public void udpsend() //UDP发射线程 ，指令分别为：上：s，下：x，左：z，右：y.
        {
            IPEndPoint receiveip = new IPEndPoint(IPAddress.Parse("127.0.0.1"), int.Parse("12345"));//目标IP，目标端口
            UdpClient udpclients = new UdpClient();
            string str = ch;
            byte[] message = Encoding.ASCII.GetBytes(str);//ascii码编码
            udpclients.Send(message, message.Length, receiveip);//发射语句
            udpclients.Close();

        }
        public void button3s_Click(object sender, EventArgs e)
        {
            try
            {
                Button but = (Button)sender;
                switch (but.Name)
                {
                    case "button3s": ch = ":s"; break;
                    case "button6x": ch = ":w"; break;
                    case "button4z": ch = ":s"; break;
                    case "button5y": ch = ":w"; break;
                }
                udps = new Thread(new ThreadStart(udpsend));
                udps.Start();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           Control.CheckForIllegalCrossThreadCalls = false;
         
           try
             {  
                 //webBrowser1.Navigate("file:///C:/Users/Administrator/Desktop/test2.html");
                 webBrowser1.Navigate("http://sherlock99.blog.lc/map2.php?latitude=39.92&longitude=116.46");
             }
             catch (Exception ex) { MessageBox.Show(ex.ToString()); }
           
        }   

        #region 控制按钮进行UDP接受,显示在lable6中
        private void button1_Click(object sender, EventArgs e)
        {
          
            udp = new Thread(new ThreadStart(udpreceive));
            udp.Start(); 
            button1.Enabled = false;
            button2.Enabled = true;

        }
        public void udpreceive()
        {
            try
            {
                char[] cha = { ',' };
                while (true)
                {
                    if (udpclient.Available > 0)
                    {
                        IPEndPoint ipe = null;
                        byte[] receivebyte = udpclient.Receive(ref ipe);
                        label8.Text = ipe.Address.ToString();
                        label9.Text = ipe.Port.ToString();
                        string str = Encoding.ASCII.GetString(receivebyte);
                        label6.Text = str;
                        str1 = str.Split(',');
                        Double longittude = Convert.ToDouble(str1[3]) / 100 + 0.24164985;
                        Double latitude = Convert.ToDouble(str1[5]) / 100+ 0.14801964;
                        label2.Text = longittude.ToString ();
                        label3.Text =latitude.ToString ();
                        webBrowser1.Navigate("http://sherlock99.blog.lc/map2.php?latitude=" + longittude.ToString() + "&longitude=" + latitude.ToString());
                        //webBrowser1.Document.InvokeScript("mark", new string[] { "30.607301", "114.361389" });//这一句是调用网页标记函数。不能正常运行
                        //udpclient .
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            udp.Suspend();
            button2.Enabled = false;
            button1.Enabled = true;
        }
        #endregion
        #region 结束相关进程
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                //Thread.Sleep(30);
                //udps.Abort();
                //if (udp .IsAlive)
                udpclient.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex .ToString ()); }
        }
        #endregion
    }
}
