﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace whut_ship_control
{
    public partial class Form_navigation2 : Form
    {
        public Form_navigation2()
        {
            InitializeComponent();
        }
    }
}
