﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace WindowsFormsApplication2
{
    [System.Runtime.InteropServices.ComVisibleAttribute(true)]
    public partial class Form1 : Form
    {
        public Thread udpr,udps;
        public  static string strings;
        public static object[] objArray = new object[2]; //纬度 经度
        public delegate void mark(string str);
        mark makeMark;
        UdpClient udpclient = new UdpClient(9998);
        public Form1()
        {
            InitializeComponent();
            webBrowser1.Navigate("file:///C:/Users/99/Desktop/map.html");
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 6;
            Control.CheckForIllegalCrossThreadCalls = false;
            makeMark = new mark(InvokeScript);                  //对UDP接收到的str的处理函数的委托
        }



        public void udpsend()                           //UDP发送线程 ，指令分别为：0--12;
        {
            IPEndPoint receiveip = new IPEndPoint(IPAddress.Parse(label9.Text), Convert.ToInt32(label15.Text));     //目标IP，目标端口
            string str = strings;
            byte[] message = Encoding.ASCII.GetBytes(str);
            udpclient.Send(message, message.Length, receiveip);
        } 

        private void button3_Click(object sender, EventArgs e)
        {
            strings = ":"+comboBox1.SelectedItem.ToString();                    //残缺文件
            udps = new Thread(new ThreadStart(udpsend));
            udps.Start();
        }


        public void udpreceive()
        {
                while (true)
                {
                    if (udpclient.Available>0)
                    {
                        IPEndPoint ipe = null;
                        byte[] receivebyte = udpclient.Receive(ref ipe);
                        label9.Text = ipe.Address.ToString();                       //显示目标IP
                        label15.Text = ipe.Port.ToString();                         //显示目标端口
                        string str = Encoding.ASCII.GetString(receivebyte);
                        this.Invoke(makeMark,str);                                  //处理数据
                        button3.Enabled = true;                                     //启用两个发送按钮
                        button4.Enabled = true;
                    }
                }
        }

        private void InvokeScript(string str)
        {
            label12.Text = str;                                         //显示接收到的数据到label12
            string[] str1 = str.Split(',');                             //第一次尝试分析数据
            if (str1.Length == 1)                                       //如果是温湿度数据
            {
                str1 = str.Split('P');
                string[] temperature_str = str1[1].Split('R');                  
                string[] humidity_str = temperature_str[1].Split('H');          
                string temperature = temperature_str[0];                        //温度
                string humidity = humidity_str[1];                              //湿度
                
            }
            else if (str1[2] == "A")                                    //如果是有效的 $GPRMC 数据
            {
                Double latitude = Convert.ToDouble(str1[3]) / 100 + 0.24164985; //纬度
                Double longitude = Convert.ToDouble(str1[5]) / 100 + 0.14801964;//经度
                label2.Text = latitude.ToString();                              //纬度
                label3.Text = longitude.ToString();                             //经度
                objArray[0] = (object)latitude;
                objArray[1] = (object)longitude;
                webBrowser1.Document.InvokeScript("mark", objArray);
                if (checkbox1.Checked)
                {
                    objArray[0] = (object)latitude;
                    objArray[1] = (object)longitude;
                    webBrowser1.Document.InvokeScript("center", objArray);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)              //开始接收
        {
            udpr = new Thread(new ThreadStart(udpreceive));
            udpr.Start();
            button1.Enabled = false;
            button2.Enabled = true;            
        }

        private void button2_Click(object sender, EventArgs e)              //停止接收
        {    
            udpclient.Close();
            udpr.Abort();
            button2.Enabled = false;
        }


        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDown1.Value > 20)
                numericUpDown1.Value = 20;
            object[] array = new object[1];
            array[0] = (object)numericUpDown1.Value;
            webBrowser1.Document.InvokeScript("zoom",array);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                object[] array = new object[1];
                array[0] = (object)2;
                webBrowser1.Document.InvokeScript("type", array);
            }
            if (radioButton2.Checked)
            {
                object[] array = new object[1];
                array[0] = (object)1;
                webBrowser1.Document.InvokeScript("type", array);
            }
        }

    }
}
