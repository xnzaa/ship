﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace WindowsFormsApplication2
{
    
    public partial class Formmain : Form
    {
        /// <summary>
        /// 全局变量的定义
        /// </summary>
        public Thread udpr,udps;
        public  static string strings;
        UdpClient udpclient = new UdpClient(9998);
        public static string[] str1;
        public static bool mar=false;
        //static  string time = System.DateTime.Now.ToString();" + time + "

        static int count = 0;
        public Formmain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 5;
            Control.CheckForIllegalCrossThreadCalls = false;
            //udps.IsBackground = true;

            try
            {
               // webBrowser1.Navigate("file:///C:/Users/Administrator/Desktop/mapv3.0.html");
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString());} 
        }


        public void udpsend() //UDP发射线程 ，指令分别为：0--12;
        {
            //try
            //{
                IPEndPoint receiveip = new IPEndPoint(IPAddress.Parse(label9.Text), Convert.ToInt32(label15.Text));//目标IP，目标端口
                string str = strings;
                byte[] message = Encoding.ASCII.GetBytes(str);//ascii码编码
                udpclient.Send(message, message.Length, receiveip);//发射语句
                sws.WriteLine (str);
            //}
            //catch (Exception ex) { MessageBox.Show(ex.Message.ToString()); }
        } 



        public void udpreceive()
        {
                IPEndPoint ipe = null;
                byte[] receivebyte;
                string str;
                Double latitude, longittude;
                while (true)
                {
                    //try
                    //{
                        if (udpclient.Available>0)
                        {
                            if (mar)
                            {
                                count = 0;
                                receivebyte = udpclient.Receive(ref ipe);
                                str = Encoding.ASCII.GetString(receivebyte);
                                label9.Text = ipe.Address.ToString();//获得目标ip
                                label15.Text = ipe.Port.ToString();//获得目标端口
                                label12.Text = str;
                                //str1 = str.Split(',');
                                //longittude = Convert.ToDouble(str1[3]) / 100 + 0.24164985;
                                //latitude = Convert.ToDouble(str1[5]) / 100 + 0.14801964;
                                //label2.Text = longittude.ToString();
                                //label3.Text = latitude.ToString();
                                //webBrowser1.Navigate("http://sherlock99.blog.lc/map2.php?latitude=" + longittude.ToString() + "&longitude=" + latitude.ToString());
                                //webBrowser1.Document.InvokeScript("mark", new string[] { "30.607301", "114.361389" });//这一句是调用网页标记函数。不能正常运行
                                swr.WriteLine(str);
                            }
                            else
                          {
                            mar = true;
                            button3.Enabled = true;
                            button4.Enabled = true;
                          }
                        }

                    //}
                    //catch (Exception ex) { MessageBox.Show(ex.Message.ToString()); }
                  }
                   
         }



        private void button1_Click(object sender, EventArgs e)//开始接收
        {
            udpr = new Thread(new ThreadStart(udpreceive));
            udpr.Start();
            udpr.IsBackground = true;
            button1.Enabled = false;
            button2.Enabled = true;            
        }

        private void button2_Click(object sender, EventArgs e)//结束接收
        {
            timer1.Stop();
            swr.Close();
            sws.Close();
            udpr.Abort  ();
            //button1.Enabled = true;
            udpclient.Close(); 
            button2.Enabled = false;
        }
        private void button3_Click(object sender, EventArgs e)//发射速度
        {
            strings = "FL I LOVE YOU !";// ":" + comboBox1.SelectedItem.ToString();
            udps = new Thread(new ThreadStart(udpsend));
            udps.Start();
           // timer1.Start();
        //  timer2.Start();
        }

        private void button4_Click(object sender, EventArgs e)//发射舵角
        {
            strings = "FL I LOVE YOU !"; //"!" + comboBox2.SelectedIndex.ToString();
            udps = new Thread(new ThreadStart(udpsend));
            udps.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            strings = "@";
            udps = new Thread(new ThreadStart(udpsend));
            udps.Start();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void gPS校正ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GPS gps = new GPS();
            gps.ShowDialog();

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (count > 5)
                MessageBox.Show("warming");
            else
                count++;
        }

        private void 修改数据保存路径ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
